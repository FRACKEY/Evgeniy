$(function () {
    let currentFloor = 7; 
    const floorPath = $('.home-image path') 
    const counterUp = $('.counter-arrow-up');
    const counterDown = $('.counter-arrow-down');
    const modal = $('.modal');
    const viewFlatsBtn = $('.view-flats');
    let currentFlat = 1;
    const flatsPath = $('.flats path'); 
    const flatsPathItem = $(".flat-item .flat-link")

    floorPath.on('mouseover', function ()  {
        floorPath.removeClass('current-floor'); 
        currentFloor = $(this).attr('data-floor');
        $('.counter').text(currentFloor) 
    });

    flatsPathItem.on('mouseover', function () {
        currentFlat = $(this).attr("data-item"); 
        console.log(currentFlat);
        flatsPath.removeClass("current-flats"); 
        flatsPathItem.removeClass("current-flats-item"); 
        $(`[data-flats=${currentFlat}]`).toggleClass("current-flats");
        $(`[data-item=${currentFlat}]`).toggleClass("current-flats-item"); 
    })
    flatsPath.on('mouseover', function () {
        currentFlats = $(this).attr("data-flats"); 
        flatsPath.removeClass("current-flats");
        flatsPathItem.removeClass("current-flats-item"); 
        $(`[data-flats=${currentFlats}]`).toggleClass("current-flats"); 
        $(`[data-item=${currentFlats}]`).toggleClass("current-flats-item"); 
    })

    viewFlatsBtn.on('click', toggleModal);

    counterUp.on('click', function () {
        if(currentFloor < floorPath.length + 1) {
            currentFloor++;
            usCurrentFloor = currentFloor.toLocaleString('en-Us', {minimumIntegerDigits: 2, useGrouping: false}); // форматирование 2 -> 02
            $('.counter').text(usCurrentFloor);
            floorPath.removeClass('current-floor')
            $(`[data-floor=${usCurrentFloor}]`).toggleClass('current-floor'); 
        }
    });
    counterDown.on('click', function () {
        if(currentFloor > 2) {
            currentFloor--;
            usCurrentFloor = currentFloor.toLocaleString('en-Us', {minimumIntegerDigits: 2, useGrouping: false});
            $('.counter').text(usCurrentFloor);
            floorPath.removeClass('current-floor')
            $(`[data-floor=${usCurrentFloor}]`).toggleClass('current-floor');
        }
    });
    
    function toggleModal() {
        modal.toggleClass('is-open');
    }

    floorPath.on('click', toggleModal);
    modal.on('click', function ({target}) {
        console.log(target)
        if (target.classList.contains('modal-close') || target.closest('.modal-close')) {
            toggleModal();
        }
    });
});